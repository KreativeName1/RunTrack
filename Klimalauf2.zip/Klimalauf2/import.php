<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin-Bereich</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
    overflow: hidden;
    }
</style>
</head>
<body>
<div class="navbar">
    <div class="navbar-logo">
        <a href="start.php"><img src="logo.png" alt="logo"></a>
    </div>
    <div class="navbar-links">
        <a href="start.php">Home</a>
        <a href="admin.php">Admin</a>
        <a href="auswahl.php">Schule</a>
        <?php if (isset($_SESSION['username'])): ?>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </div>
</div>
<div class="container">
    <div class="left">
        <img src="bild4.jpg" alt="Klimalauf Bild">
    </div>
    <div class="admin">
        <h1>Datenbank importieren</h1>
        <form method="post" action="import2.php" enctype="multipart/form-data">
            <div class="file-input-container">
                <input class="dbutton" type="file" id="file-input" name="file" accept=".db">
                <label for="file-input">Datei auswählen</label>
            <button class="dbutton">Importieren</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var toast = document.getElementById("toast");
        if (toast) {
            setTimeout(function () {
                toast.className = toast.className.replace("show", "");
            }, 3000);
        }
    });
</script>
</body>
</html>
