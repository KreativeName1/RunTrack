<?php
session_start();

// Prüfen, ob der Benutzer eingeloggt und ein Admin ist
if (!isset($_SESSION['username']) /*|| $_SESSION['role'] !== 'admin'*/) {
    $_SESSION['toast_message'] = "Zugriff ist ausschließlich für Admins vorgesehen.";
    header('Location: admin.php');
    exit;
}

// Überprüfen, ob eine Datei hochgeladen wurde
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['sql_file'])) {
    $info = pathinfo($_FILES['file']['name']);
    $newname = "Datenbank.".$info['extension'];
    move_uploaded_file($_FILES['file']['tmp_name'], $newname);
    exit;


    header('Location: admin.php');
    exit;
} else {
    $_SESSION['toast_message'] = "Keine Datei ausgewählt.";
    header('Location: admin.php');
    exit;
}
?>
