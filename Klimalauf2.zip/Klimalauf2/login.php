<link rel="stylesheet" href="style.css">
<?php
session_start();


$valid_username = 'admin';
$valid_password = 'password123';

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username == $valid_username && $password == $valid_password) {
        $_SESSION['username'] = $username;
        $_SESSION['login_success'] = true;
        header('Location: start.php'); // Weiterleitung zur Startseite
        exit;
    } else {
        $error_message = 'Ungültiger Benutzername oder Passwort.';
    }
}
?>
    <title>Login</title>
    <style>
    body {
    overflow: hidden;
    }
</style>
</head>
<body>
<div class="navbar">
        <div class="navbar-logo">
            <a href="start.php"><img src="logo.png" alt="logo"></a>
        </div>
        <div class="navbar-links">
            <a href="start.php">Home</a>
            <a href="admin.php">Admin</a>
            <a href="auswahl.php">Schule</a>
            <?php if (isset($_SESSION['username'])): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="container">
        <div class="left">
            <img src="bild4.jpg" alt="Klimalauf Bild">
        </div>
        <div class="right">
        <h1>Login</h1>
        <form method="post" action="login.php">
            <div class="input-group">
                <input type="text" placeholder="Benutzername" id="username" name="username" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Passwort" id="password" name="password" required>
            </div>
            <button class="button">Einloggen</button>
        </form>
        <?php if ($error_message): ?>
            <div id="toast" class="toast show"><?php echo $error_message; ?></div>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var toast = document.getElementById("toast");
            if (toast) {
                setTimeout(function () {
                    toast.className = toast.className.replace("show", "");
                }, 3000);
            }
        });
    </script>
</body>
</html>
