<?php
session_start();
$login_success_message = '';

if (isset($_SESSION['login_success']) && $_SESSION['login_success']) {
    $login_success_message = 'Erfolgreich eingeloggt.';
    unset($_SESSION['login_success']); // Entferne die Erfolgsvariable
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
    overflow: hidden;
    }
</style>
</head>
<body>
<div class="navbar">
        <div class="navbar-logo">
        <a href="start.php"><img src="logo.png" alt="logo"></a>
        </div>
        <div class="navbar-links">
            <a href="start.php">Home</a>
            <a href="admin.php">Admin</a>
            <a href="auswahl.php">Schule</a>
            <?php if (isset($_SESSION['username'])): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="container">
        <div class="left">
            <img src="bild4.jpg" alt="Klimalauf Bild">
        </div>
        <div class="strt">
                <h1>Willkommen zum Klimalauf</h1>
                <p>Verfolgen Sie Ihre Fortschritte und sehen Sie, wie viele Runden Sie und andere Teilnehmer gelaufen sind.</p>
        </div>
    </div>
    <?php if ($login_success_message): ?>
    <div id="toast" class="toast show2"><?php echo $login_success_message; ?></div>
<?php endif; ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var toast = document.getElementById("toast");
        if (toast) {
            setTimeout(function () {
                toast.className = toast.className.replace("show", "");
            }, 3000);
        }
    });
</script>
</body>
</html>