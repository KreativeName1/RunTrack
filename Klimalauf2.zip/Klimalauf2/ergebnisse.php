<?php
session_start();

$dbfile = 'Auswertung.db';

if (file_exists($dbfile)) {
    echo("Die Datei <code>$dbfile</code> existiert.<p>");
} else {
    echo("Die Datei <code>$dbfile</code> existiert nicht.<p>");
}

$db = new PDO("sqlite:$dbfile");

// Falls die Tabellen noch nicht existieren, erstellen Sie sie (nur für Testzwecke):
// $db->exec("
//     CREATE TABLE IF NOT EXISTS Schulen (
//         Id INTEGER PRIMARY KEY,
//         Name TEXT
//     );
//     CREATE TABLE IF NOT EXISTS Klassen (
//         Id INTEGER PRIMARY KEY,
//         Name TEXT,
//         SchuleId INTEGER,
//         RundenArtId INTEGER,
//         Jahrgang INTEGER,
//         FOREIGN KEY (SchuleId) REFERENCES Schulen(Id),
//         FOREIGN KEY (RundenArtId) REFERENCES RundenArten(Id)
//     );
//     CREATE TABLE IF NOT EXISTS Schueler (
//         Id INTEGER PRIMARY KEY,
//         Vorname TEXT,
//         Nachname TEXT,
//         Geschlecht TEXT,
//         KlassenId INTEGER,
//         FOREIGN KEY (KlassenId) REFERENCES Klassen(Id)
//     );
//     CREATE TABLE IF NOT EXISTS Runden (
//         Id INTEGER PRIMARY KEY,
//         BenutzerName TEXT,
//         Zeitstempel TIMESTAMP,
//         SchuelerId INTEGER,
//         FOREIGN KEY (SchuelerId) REFERENCES Schueler(Id)
//     );
//     CREATE TABLE IF NOT EXISTS RundenArten (
//         Id INTEGER PRIMARY KEY,
//         Name TEXT,
//         LaengeInMeter INTEGER
//     );
// ");

$school = '';
$class = '';
$results = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['school'])) {
        $school = $_POST['school'];
    }
    if (isset($_POST['class'])) {
        $class = $_POST['class'];
    }

    $stmt = $db->prepare("
        SELECT 
            s.Vorname, 
            s.Nachname, 
            r.Zeitstempel, 
            ra.Name as RundenArt, 
            ra.LaengeInMeter 
        FROM Schueler s
        JOIN Klassen k ON s.KlasseId = k.Id
        JOIN Schulen sch ON k.SchuleId = sch.Id
        JOIN Runden r ON s.Id = r.SchuelerId
        JOIN RundenArten ra ON k.RundenArtId = ra.Id
        WHERE sch.Name = ? AND k.Name = ?
    ");
    $stmt->execute([$school, $class]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt->closeCursor();
}

$db = null;
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ergebnisse</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #ffffff;
    height: 100vh;
    color: #ffffff;
    background-color: #73787E; 
    justify-content: center;
    display: fixed;
}
.container {
    display: flex;
    gap: 0rem;
    align-items: center;
}
.left {   
    background-size: cover; 
    max-width: 1000px;
    max-height: 800px;
}
.left img {
    position: fixed;
}
.right {
    align-items: center;
    justify-content: center;
    text-align: center;
    margin-top: 120px;
}
h1 {
    font-size: 2.5em;
    color: #ffffff;
    margin-left: 450px;
    margin-top: 0px;
}
p {
    font-size: 1.2em;
    text-align: center;
}
    </style>
</head>
<body>
    <div class="navbar">
        <div class="navbar-logo">
            <a href="start.php"><img src="logo.png" alt="logo"></a>
        </div>
        <div class="navbar-links">
            <a href="start.php">Home</a>
            <a href="admin.php">Admin</a>
            <a href="auswahl.php">Schule</a>
            <?php if (isset($_SESSION['username'])): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="left">
            <img src="bild4.jpg" alt="Klimalauf Bild">
        </div>
        <div class="right">
            <h1>Ergebnisse</h1>
        
            <?php if (!empty($results)): ?>
                <table class="results-table">
                    <thead>
                        <tr>
                            <th>Vorname</th>
                            <th>Nachname</th>
                            <th>Zeitstempel</th>
                            <th>RundenArt</th>
                            <th>Länge in Meter</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $result): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($result['Vorname']); ?></td>
                                <td><?php echo htmlspecialchars($result['Nachname']); ?></td>
                                <td><?php echo htmlspecialchars($result['Zeitstempel']); ?></td>
                                <td><?php echo htmlspecialchars($result['RundenArt']); ?></td>
                                <td><?php echo htmlspecialchars($result['LaengeInMeter']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
                <p>Es wurden keine Ergebnisse für diese Suche gefunden oder unter dem Menüpunkt 'Admin' wurde noch keine Datei importiert.</p>
            <?php endif; ?>
        </div>

    <script src="script.js"></script>
</body>
</html>
